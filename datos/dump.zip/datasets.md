* Bilbao's_Iron_Ring <http://dbpedia.org/resource/Bilbao\u0027s_Iron_Ring> [NO DATE, OBVIOUSLY]
* Campaign_of_Gipuzkoa dbr:Campaign_of_Gipuzkoa
* Siege_of_Cuartel_de_Loyola dbr:Siege_of_Cuartel_de_Loyola
* Villarreal_Offensive dbr:Villarreal_Offensive
* War_in_the_North dbr:War_in_the_North
* Battle_of_Bilbao dbr:Battle_of_Bilbao
* Battle_of_Cape_Machichaco dbr:Battle_of_Cape_Machichaco
* Battle_of_Ir�n <http://dbpedia.org/resource/Battle_of_Ir\u00FAn>
* es.dbpedia.org.resource.Batalla_de_sollube <http://es.dbpedia.org/resource/Batalla_de_Sollube> [foaf:isPrimaryTopicOf instead of foaf:primaryTopic]

* Bombardeos
* Fosas comunes
* Personas desaparecidas
* Normas legegunea
